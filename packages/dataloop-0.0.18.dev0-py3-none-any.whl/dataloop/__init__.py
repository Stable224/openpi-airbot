"""DataLoop SDK for interacting with DataLoop API"""
from __future__ import annotations

try:
    from ._version import __version__
except ImportError:
    __version__ = "0.0.2.dev"

from .api.client import DataLoopClient

__all__ = ['DataLoopClient']
