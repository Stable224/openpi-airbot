"""Custom exceptions for DataLoop SDK."""


class DataLoopError(Exception):
    """Base exception for DataLoop SDK."""


class APIError(DataLoopError):
    """Exception raised for API errors."""


class AuthenticationError(DataLoopError):
    """Exception raised for authentication errors."""


class ValidationError(DataLoopError):
    """Exception raised for validation errors."""
