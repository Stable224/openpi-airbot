"""Credentials management module."""
import logging
from typing import Dict

import jwt
import requests

logger = logging.getLogger(__name__)


class Credentials:
    """Manages authentication credentials."""

    def __init__(self, username: str, password: str, login_url: str):
        """Initialize credentials.

        Args:
            username: Username for authentication
            password: Password for authentication
            login_url: URL for login endpoint
        """
        self.username = username
        self._password = password
        self._login_url = login_url
        self._token = None
        self._user_id = None
        self._login()

    def _login(self):
        """Perform login and get authentication token."""
        try:
            response = requests.post(self._login_url,
                                     json={
                                         "username": self.username,
                                         "password": self._password
                                     })
            try:
                response.raise_for_status()
            except requests.exceptions.RequestException as e:
                raise ValueError(f"Login failed: {e}") from e
            response_data = response.json()
            access_token = response_data.get("access_token")
            self._token = access_token

            logger.info("Successfully logged in as: %s", self.username)

        except requests.exceptions.RequestException as e:
            logger.error("Login failed: %s", e)
            raise ValueError(f"Login failed: {e}")

    def get_headers(self) -> Dict[str, str]:
        """Get authentication headers.

        Returns:
            Dictionary containing authentication headers
        """
        if not self._token:
            self._login()
        return {"Authorization": f"{self._token}"}

    def get_user_id(self) -> str:
        """Get authenticated user ID.

        Returns:
            User ID string
        """
        if not self._user_id:
            self._login()
        return self._user_id
