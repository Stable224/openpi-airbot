"""URL utilities."""
from urllib.parse import urljoin


class BaseURL:
    """Base URL handler."""

    def __init__(self, url: str):
        """Initialize with base URL.

        Args:
            url: Base URL string
        """
        self.url = url.rstrip('/')

    def __str__(self) -> str:
        """Get string representation.

        Returns:
            Base URL as string
        """
        return self.url

    def join(self, path: str) -> str:
        """Join path with base URL.

        Args:
            path: Path to join

        Returns:
            Complete URL
        """
        return urljoin(self.url + '/', path.lstrip('/'))
