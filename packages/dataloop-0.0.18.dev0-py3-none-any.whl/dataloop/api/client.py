"""DataLoop Client module."""
import logging
from typing import Optional
from ..auth import Credentials
from ..utils.url import BaseURL
from .projects import ProjectAPI
from .samples import SampleAPI
from .snapshots import SnapshotAPI

logger = logging.getLogger(__name__)


class DataLoopClient:
    """Main client class for interacting with DataLoop API."""

    def __init__(
        self,
        endpoint: str,
        username: Optional[str] = None,
        password: Optional[str] = None,
        secure: bool = False,
    ):
        """Initialize DataLoop client.

        Args:
            endpoint: API endpoint
            username: Optional username for authentication
            password: Optional password for authentication
            secure: Whether to use HTTPS
        """
        self._base_url = BaseURL(("https://" if secure else "http://") +
                                 endpoint)
        self.login_url = BaseURL(f"{self._base_url}/usermange/api/users/login")
        #self.login_url = BaseURL(f"http://127.0.0.1:5005/api/users/login")
        self._setup_credentials(username, password)
        self._setup_api_modules()

    def _setup_credentials(self, username: Optional[str],
                           password: Optional[str]):
        """Setup authentication credentials."""
        if username:
            if not password:
                raise ValueError("Username must be provided with password.")
            self._credentials = Credentials(
                username=username,
                password=password,
            # login_url=f"{self._base_url}/usermange/api/users/login")
                login_url=self.login_url)

            logger.info("Credentials set for user: %s", username)
        else:
            self._credentials = None
            logger.info("Anonymous access configured.")

    def _setup_api_modules(self):
        """Initialize API modules."""
        self.projects = ProjectAPI(self._base_url, self._credentials)
        self.samples = SampleAPI(self._base_url, self._credentials)
        self.snapshots = SnapshotAPI(self._base_url, self._credentials)
