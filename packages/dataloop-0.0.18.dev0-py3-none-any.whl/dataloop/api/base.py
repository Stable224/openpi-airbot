"""Base API module with common functionality."""
import logging
from typing import Optional, Dict, Any
import requests
import io
from ..exceptions import APIError
from ..auth import Credentials
from ..utils.url import BaseURL

logger = logging.getLogger(__name__)


class BaseAPI:
    """Base class for all API modules."""

    def __init__(self, base_url: BaseURL, credentials: Optional[Credentials]):
        """Initialize base API.

        Args:
            base_url: Base URL for API endpoints
            credentials: Optional credentials for authentication
        """
        self._base_url = base_url
        self._credentials = credentials

    def _send_request(self,
                      method: str,
                      endpoint: str,
                      headers: Optional[Dict] = None,
                      params: Optional[Dict] = None,
                      data: Optional[Dict] = None) -> Dict[str, Any]:
        """Send HTTP request to API endpoint.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            headers: Optional request headers
            params: Optional query parameters
            data: Optional request body data

        Returns:
            Response data as dictionary

        Raises:
            APIError: If request fails
        """
        url = f"{self._base_url}{endpoint}"
        logger.debug("Sending %s request to %s", method, url)
        try:
            response = requests.request(method=method,
                                        url=url,
                                        headers=headers,
                                        params=params,
                                        json=data)
            response.raise_for_status()
            logger.info("%s request to %s succeeded", method, url)
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error("%s request to %s failed: %s", method, url, e)
            raise APIError(f"Request failed: {e}") from e

    def _send_file_request(self,
                           method: str,
                           endpoint: str,
                           headers: Optional[Dict] = None,
                           files: Optional[Dict] = None,
                           data: Optional[Dict] = None) -> Dict[str, Any]:
        """Send HTTP request with file upload/download.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            headers: Optional request headers
            files: Files to upload

        Returns:
            Response data as dictionary

        Raises:
            APIError: If request fails
        """
        url = f"{self._base_url}{endpoint}"
        logger.debug("Sending %s request with file to %s", method, url)

        try:
            response = requests.request(method=method,
                                        url=url,
                                        headers=headers,
                                        files=files,
                                        data=data)
            response.raise_for_status()
            logger.info("%s request with file to %s succeeded", method, url)
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error("%s request with file to %s failed: %s", method, url,
                         e)
            raise APIError(f"Request failed: {e}") from e

    def _send_image_request(self,
                            method: str,
                            endpoint: str,
                            headers: Optional[Dict] = None,
                            params: Optional[Dict] = None,
                            data: Optional[Dict] = None,
                            return_binary: bool = False) -> Any:
        """Send HTTP request to API endpoint.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            headers: Optional request headers
            params: Optional query parameters
            data: Optional request body data
            return_binary: Whether to return the response content as binary (BytesIO)

        Returns:
            Response data as dictionary or binary (BytesIO)

        Raises:
            APIError: If request fails
        """
        url = f"{self._base_url}{endpoint}"
        logger.debug("Sending %s request to %s", method, url)

        try:
            response = requests.request(method=method,
                                        url=url,
                                        headers=headers,
                                        params=params,
                                        json=data)
            response.raise_for_status()
            logger.info("%s request to %s succeeded", method, url)

            if return_binary:
                return io.BytesIO(response.content)    # Return binary content
            return response.json()    # Parse JSON content

        except requests.exceptions.RequestException as e:
            logger.error("%s request to %s failed: %s", method, url, e)
            raise APIError(f"Request failed: {e}") from e

    def _get_headers(self) -> Dict[str, str]:
        """Get request headers with authentication if available."""
        headers = {'Content-Type': 'application/json'}
        if self._credentials:
            headers.update(self._credentials.get_headers())
        return headers
