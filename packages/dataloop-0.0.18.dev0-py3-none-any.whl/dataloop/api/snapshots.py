"""Snapshots API module."""
import logging
from typing import Dict, List, Optional
from .base import BaseAPI
import io
import requests
import json
import time

logger = logging.getLogger(__name__)


class SnapshotAPI(BaseAPI):
    """API for managing snapshots."""

    def list_snapshots(self) -> Dict[str, List]:
        """List all snapshots.

        Returns:
            Dictionary containing list of snapshots
        """
        logger.info("Listing all snapshots")
        headers = self._get_headers()
        response = self._send_request("GET",
                                      "/dataserver/api/snapshots",
                                      headers=headers)
        return {"data": response.get("data", [])}

    def create_snapshot(self,
                        project_id: int,
                        test_percent: int,
                        train_percent: int,
                        val_percent: int,
                        tags: dict,
                        snapshot_tags: dict = None,
                        snapshot_description: str = None,
                        snapshot_split_tag_key: str = None,
                        splitting_tag_key_value: list = None,
                        splitting_tag_key_max_count: int = None):
        headers = self._get_headers()
        percent = test_percent + train_percent + val_percent
        if percent != 100:
            logger.error(
                "test_percent + train_percent + vail_percent must be equal to 100"
            )
            return None
        payload_query = {
            "project_ids": [project_id],
            "test_percent": test_percent,
            "train_percent": train_percent,
            "val_percent": val_percent,
            "tags": tags,
            "create_type": "train",
            "time_frame": []
        }
        sample_ids_reponse = self._send_request(
            "POST",
            "/dataserver/api/samples/datapoints/pictures",
            headers=headers,
            data=payload_query)
        sample_ids_list = []
        sample_ids = sample_ids_reponse.get('sample_ids', [])
        for sample_id in sample_ids:
            sample_ids_list.append(sample_id)
        create_record = json.dumps({
            "project_ids": [f"{project_id}"],
            "time_frame": [],
            "tags": tags
        })
        playload_snapshot = {
            "create_record": create_record,
            "sample_ids": sample_ids_list,
            "test_percent": test_percent,
            "tags": snapshot_tags,
            "description": snapshot_description,
            "splitting_tag_key": snapshot_split_tag_key,
            "splitting_tag_key_value": splitting_tag_key_value,
            "splitting_tag_key_max_count": splitting_tag_key_max_count,
            "training_percent": train_percent,
            "validation_percent": val_percent,
            "user_id": self._credentials._user_id,
            "user_name": self._credentials.username
        }

        response = self._send_request("POST",
                                      "/dataserver/api/snapshots",
                                      headers=headers,
                                      data=playload_snapshot)
        return response.get("snapshot_id", "")

    def load_snapshots_samples(self, snapshot_id: str,
                               sample_type: str) -> Optional[List]:
        """
        Get all training data list for the specified snapshot ID.

        Args:
            snapshot_id (str): The ID of the snapshot

        Returns:
            Optional[List[Dict[str, Any]]]: List of training data, returns None if request fails
        """
        headers = self._get_headers()
        payload = {"sample_type": sample_type}
        logger.info("Listing samples for snapshot ID: %s", snapshot_id)
        response = self._send_request(
            "POST",
            f"/dataserver/api/snapshots/{snapshot_id}/get_all_train_list",
            headers=headers,
            data=payload)

        return response.get('data', [])

    def load_samples_data(self, sample_id: str):
        """
        Get training data image for the specified data ID.

        Args:
            data_id (str): The ID of the training data

        Returns:
            Optional[io.BytesIO]: BytesIO object containing image data, returns None if request fails
        """
        headers = self._get_headers()
        payload = {"sample_id": sample_id}
        response = self._send_image_request(
            "POST",
            endpoint="/dataserver/api/snapshots/get_train_data",
            headers=headers,
            data=payload,
            return_binary=True)

        return response
