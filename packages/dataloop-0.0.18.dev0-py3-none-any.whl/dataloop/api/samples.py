"""Samples API module."""
import json
import os
import logging
from typing import List, Dict
import requests
from ..exceptions import APIError
from .base import BaseAPI

logger = logging.getLogger(__name__)


class SampleAPI(BaseAPI):
    """API for managing samples."""

    def list_samples(self, project_id: str) -> List[Dict]:
        """List samples for a project.

        Args:
            project_id: ID of the project

        Returns:
            List of sample dictionaries
        """
        logger.info("Listing samples for project ID: %s", project_id)
        headers = self._get_headers()
        del headers["Content-Type"]
        response = self._send_request(
            "GET",
            f"/dataserver/api/samples?project_id={project_id}",
        # f"/api/samples?project_id={project_id}",
            headers=headers)
        return [{
            "sample_id": s["sample_id"],
            "create_user": s["create_user"],
            "creation_time": s["creation_time"]
        } for s in response.get("data", [])]

    def get_minio_config(self) -> dict:
        """Get MinIO configuration for a project from API.

        Args:
            project_id: ID of the project

        Returns:
            Dictionary containing MinIO configuration:
            {
                'endpoint': 'minio.example.com:9000',
                'access_key': 'access_key',
                'secret_key': 'secret_key',
                'bucket_name': 'project-bucket',
                'secure': True
            }

        Raises:
            APIError: If configuration retrieval fails
        """

        try:
            headers = self._get_headers()
            response = self._send_request("GET",
                                          f"/dataserver/api/minio-config",
                                          headers=headers)

            config = response.get("minio_config", {})
            logger.info(
                "MinIO configuration retrieved successfully for project")

            return config

        except APIError as e:
            logger.warning("Failed to fetch MinIO config for project %s: %s", e)
            raise APIError(f"Failed to fetch MinIO configuration: {e}") from e

    def parse_mcap_metadata(self,file_path):
        tags = {}
        operator = "anonymous"
        from mcap.reader import make_reader
        with open(file_path, "rb") as f:
            reader = make_reader(f)
            stats = reader.get_summary().statistics
            start_time_ns = stats.message_start_time
            end_time_ns = stats.message_end_time
            duration_sec = (end_time_ns - start_time_ns) / 1e9
            message_count = stats.message_count
            channel_count = stats.channel_count
            frequency = round(message_count / channel_count / duration_sec, 2)
            tags = {item.name: item.metadata for item in reader.iter_metadata() if item.name != "upload"}
            from datetime import datetime

            tags.update({"summary":{
                "start_time": datetime.fromtimestamp(start_time_ns / 1e9).astimezone().strftime("%Y-%m-%d %H:%M:%S"),
                "end_time": datetime.fromtimestamp(end_time_ns / 1e9).astimezone().strftime("%Y-%m-%d %H:%M:%S"),
                "duration": f"{duration_sec:.2f}s",
                "frequency": f"{frequency}Hz",
                "channels": channel_count,
                "messages": message_count,
            }})
            # 提取操作人信息
            operator = tags.get("task_info").get("operator",operator)

        return tags, operator, message_count
    def upload_sample(self,
                      project_id: str = None,
                      sample_id: str = None,
                      sample_type: str = "Sequential",
                      version: int = 1,
                      file_path: str = None) -> str:

        import uuid
        import os

        logger.info("Creating sample metadata for project ID")

        # Generate sample ID if not provided
        sample_uuid = sample_id or str(uuid.uuid4())

        # Get MinIO configuration
        final_config = self._resolve_minio_config()

        # Transaction state tracking
        minio_uploaded = False
        metadata_created = False
        file_url = None
        s3_client = None
        object_name = None
        tags, operator, total_datapoints = self.parse_mcap_metadata(file_path)
        try:
            # Step 1: Upload file to MinIO if file_path is provided
            if file_path:
                logger.info("Starting MinIO file upload for sample: %s",
                            sample_uuid)
                file_url, s3_client, object_name = self._upload_to_minio_with_client(
                    file_path=file_path,
                    sample_id=sample_uuid,
                    bucket_name=final_config['bucket_name'],
                    minio_endpoint=final_config['endpoint'],
                    minio_access_key=final_config['access_key'],
                    minio_secret_key=final_config['secret_key'],
                    minio_secure=final_config['secure'])
                minio_uploaded = True
                logger.info("MinIO upload completed successfully")

            # Step 2: Create metadata record
            logger.info("Creating sample metadata for sample: %s", sample_uuid)

            sample_data = {
                "project_id": project_id,
                "sample_id": sample_uuid,
                "operator": operator or "No_User",
                "type": sample_type,
                "version": version,
                "tags": tags or {},
                "total_datapoints": total_datapoints
            }

            # Add file URL to metadata if file was uploaded
            if file_url:
                sample_data["file_url"] = file_url

            # Send metadata to the server
            headers = self._get_headers()
            response = self._send_request("POST",
                                          "/dataserver/api/samples/upload_file",
                                          headers=headers,
                                          data=sample_data)
            metadata_created = True
            logger.info("Sample metadata created successfully: %s", sample_uuid)

            # Both operations succeeded
            upload_message = f"Sample uploaded successfully with ID: {sample_uuid}"
            if file_url:
                upload_message += f", file uploaded to MinIO: {file_url}"

            return upload_message

        except Exception as e:
            logger.error("Upload failed, initiating rollback for sample: %s",
                         sample_uuid)

            # Rollback operations in reverse order
            rollback_errors = []

            # Rollback metadata creation (if supported by API)
            if metadata_created:
                try:
                    logger.info("Rolling back metadata creation for sample: %s",
                                sample_uuid)
                    self._rollback_metadata(sample_uuid)
                    logger.info("Metadata rollback completed")
                except Exception as rollback_err:
                    rollback_errors.append(
                        f"Metadata rollback failed: {rollback_err}")
                    logger.error("Metadata rollback failed: %s", rollback_err)

            # Rollback MinIO upload
            if minio_uploaded and s3_client and object_name and final_config.get(
                    'bucket_name'):
                try:
                    logger.info("Rolling back MinIO upload for sample: %s",
                                sample_uuid)
                    self._rollback_minio_upload(s3_client,
                                                final_config['bucket_name'],
                                                object_name)
                    logger.info("MinIO rollback completed")
                except Exception as rollback_err:
                    rollback_errors.append(
                        f"MinIO rollback failed: {rollback_err}")
                    logger.error("MinIO rollback failed: %s", rollback_err)

            # Prepare error message
            error_msg = f"Upload failed for sample {sample_uuid}: {e}"
            if rollback_errors:
                error_msg += f". Rollback errors: {'; '.join(rollback_errors)}"

            raise APIError(error_msg) from e

    def _resolve_minio_config(self) -> dict:
        """Resolve MinIO configuration from multiple sources.

        Args:
            project_id: Project ID for fetching API config
            auto_config: Whether to fetch config from API
            bucket_name: Manual bucket name
            minio_endpoint: Manual endpoint
            minio_access_key: Manual access key
            minio_secret_key: Manual secret key
            minio_secure: Manual secure setting

        Returns:
            Dictionary with resolved configuration
        """
        import os

        # Start with default config
        config = {
            'endpoint': None,
            'access_key': None,
            'secret_key': None,
            'bucket_name': None,
            'secure': False
        }

        # Step 1: Try to get config from API if auto_config is enabled
        try:
            api_config = self.get_minio_config()
            logger.info("Using MinIO configuration from API")
            config.update({
                'endpoint': api_config.get('endpoint'),
                'access_key': api_config.get('access_key'),
                'secret_key': api_config.get('secret_key'),
                'bucket_name': api_config.get('bucket_name'),
                'secure': api_config.get('secure', False)
            })
        except APIError as e:
            logger.warning(
                "Could not fetch MinIO config from API, falling back to manual/env config: %s",
                e)

        # Step 3: Fall back to environment variables for missing values
        if not config['endpoint']:
            config['endpoint'] = os.getenv('MINIO_ENDPOINT')
        if not config['access_key']:
            config['access_key'] = os.getenv('MINIO_ACCESS_KEY') or os.getenv(
                'AWS_ACCESS_KEY_ID')
        if not config['secret_key']:
            config['secret_key'] = os.getenv('MINIO_SECRET_KEY') or os.getenv(
                'AWS_SECRET_ACCESS_KEY')
        if not config['bucket_name']:
            config['bucket_name'] = os.getenv('MINIO_BUCKET_NAME')

        # Validate required config
        missing_fields = [
            k for k, v in config.items() if v is None and k != 'secure'
        ]
        if missing_fields:
            raise APIError(
                f"Missing MinIO configuration: {', '.join(missing_fields)}. "
                f"Provide via API config, manual parameters, or environment variables."
            )
        logger.info("Resolved MinIO config - endpoint: %s, bucket: %s",
                    config['endpoint'], config['bucket_name'])
        return config

    def _upload_to_minio_with_client(self,
                                     file_path: str,
                                     sample_id: str,
                                     bucket_name: str,
                                     minio_endpoint: str = None,
                                     minio_access_key: str = None,
                                     minio_secret_key: str = None,
                                     minio_secure: bool = True) -> tuple:
        """Upload file to MinIO storage using boto3 and return client for rollback.

        Returns:
            tuple: (file_url, s3_client, object_name)
        """
        try:
            import boto3
            from botocore.exceptions import ClientError, NoCredentialsError
        except ImportError:
            raise APIError(
                "boto3 package is required for file upload. Install with: pip install boto3"
            )

        import os

        # Get MinIO configuration from environment variables if not provided
        endpoint = minio_endpoint or os.getenv('MINIO_ENDPOINT')
        access_key = minio_access_key or os.getenv(
            'MINIO_ACCESS_KEY') or os.getenv('AWS_ACCESS_KEY_ID')
        secret_key = minio_secret_key or os.getenv(
            'MINIO_SECRET_KEY') or os.getenv('AWS_SECRET_ACCESS_KEY')
        region = os.getenv('AWS_DEFAULT_REGION', 'us-east-1')

        if not all([endpoint, access_key, secret_key, bucket_name]):
            raise APIError(
                "MinIO configuration incomplete. Provide endpoint, access_key, secret_key, and bucket_name"
            )

        if not os.path.exists(file_path):
            raise APIError(f"File not found: {file_path}")

        try:
            # Build endpoint URL
            protocol = "https" if minio_secure else "http"
            endpoint_url = f"{protocol}://{endpoint}"

            # Create boto3 S3 client for MinIO
            s3_client = boto3.client(
                's3',
                endpoint_url=endpoint_url,
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key,
                region_name=region,
                use_ssl=minio_secure,
                verify=minio_secure    # SSL verification
            )

            # Check if bucket exists, create if not
            try:
                s3_client.head_bucket(Bucket=bucket_name)
                logger.info("Bucket %s exists", bucket_name)
            except ClientError as e:
                error_code = e.response['Error']['Code']
                if error_code == '404':
                    # Bucket doesn't exist, create it
                    try:
                        s3_client.create_bucket(Bucket=bucket_name)
                        logger.info("Created bucket: %s", bucket_name)
                    except ClientError as create_error:
                        logger.error("Failed to create bucket %s: %s",
                                     bucket_name, create_error)
                        raise APIError(
                            f"Failed to create bucket {bucket_name}: {create_error}"
                        ) from create_error
                else:
                    logger.error("Error checking bucket %s: %s", bucket_name, e)
                    raise APIError(
                        f"Error checking bucket {bucket_name}: {e}") from e

            # Generate object name using sample_id
            object_name = f"{sample_id}/{sample_id}.mcap"

            # Upload file
            logger.info("Uploading file %s to MinIO bucket %s as %s", file_path,
                        bucket_name, object_name)

            # Get file size for progress tracking
            file_size = os.path.getsize(file_path)
            logger.info("File size: %d bytes", file_size)

            s3_client.upload_file(Filename=file_path,
                                  Bucket=bucket_name,
                                  Key=object_name)

            # Generate file URL
            file_url = f"{endpoint_url}/{bucket_name}/{object_name}"

            logger.info("File uploaded successfully to MinIO: %s", file_url)
            return file_url, s3_client, object_name

        except NoCredentialsError as e:
            logger.error("AWS credentials not found: %s", e)
            raise APIError(f"AWS credentials not found: {e}") from e
        except ClientError as e:
            logger.error("MinIO upload failed: %s", e)
            raise APIError(f"MinIO upload failed: {e}") from e
        except Exception as e:
            logger.error("Unexpected error during MinIO upload: %s", e)
            raise APIError(f"Unexpected error during MinIO upload: {e}") from e

    def _rollback_minio_upload(self, s3_client, bucket_name: str,
                               object_name: str):
        """Rollback MinIO upload by deleting the uploaded file.

        Args:
            s3_client: Boto3 S3 client instance
            bucket_name: Name of the bucket
            object_name: Name of the object to delete
        """
        try:
            from botocore.exceptions import ClientError

            logger.info("Deleting MinIO object: %s/%s", bucket_name,
                        object_name)
            s3_client.delete_object(Bucket=bucket_name, Key=object_name)
            logger.info("MinIO object deleted successfully")

        except ClientError as e:
            # If object doesn't exist, that's fine
            if e.response['Error']['Code'] == 'NoSuchKey':
                logger.info("MinIO object %s/%s already doesn't exist",
                            bucket_name, object_name)
            else:
                raise APIError(f"Failed to delete MinIO object: {e}") from e
        except Exception as e:
            raise APIError(
                f"Unexpected error during MinIO rollback: {e}") from e

    def _rollback_metadata(self, sample_id: str):
        """Rollback metadata creation by deleting the sample record.

        Args:
            sample_id: ID of the sample to delete

        Note: This requires the API to support sample deletion
        """
        try:
            logger.info("Attempting to delete sample metadata: %s", sample_id)
            headers = self._get_headers()

            # Try to delete the sample - this assumes your API supports DELETE
            try:
                self._send_request("DELETE",
                                   f"/api/samples/{sample_id}",
                                   headers=headers)
                logger.info("Sample metadata deleted successfully: %s",
                            sample_id)
            except APIError as e:
                # If the API doesn't support deletion or sample doesn't exist, log but don't fail
                if "404" in str(e) or "Not Found" in str(e):
                    logger.info(
                        "Sample metadata %s not found (may not have been created)",
                        sample_id)
                elif "405" in str(e) or "Method Not Allowed" in str(e):
                    logger.warning(
                        "API doesn't support sample deletion - manual cleanup may be required for sample: %s",
                        sample_id)
                else:
                    raise    # Re-raise other API errors

        except Exception as e:
            logger.error("Error during metadata rollback for sample %s: %s",
                         sample_id, e)
            raise APIError(f"Metadata rollback failed: {e}") from e

    def download_sample(self, sample_id: str, file_path: str) -> str:
        """Download a sample file.

        Args:
            sample_id: ID of the sample to download
            file_path: Directory path to save the file

        Returns:
            Path to downloaded file

        Raises:
            APIError: If download fails
        """
        logger.info("Downloading sample with ID: %s", sample_id)
        endpoint = f"/dataserver/api/samples/{sample_id}/download"
        filename = f"{sample_id}.bson"
        os.makedirs(file_path, exist_ok=True)
        output_path = os.path.join(file_path, filename)

        headers = self._get_headers()
        url = f"{self._base_url}{endpoint}"

        try:
            response = requests.get(url, headers=headers, stream=True)
            response.raise_for_status()
            with open(output_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        except requests.exceptions.RequestException as e:
            logger.error("Download failed for sample ID %s: %s", sample_id, e)
            raise APIError(f"Download failed: {e}") from e

        logger.info("File downloaded successfully to: %s", output_path)

        return f"File downloaded successfully to: {output_path}"
