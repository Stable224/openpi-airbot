"""Projects API module."""
import logging
from typing import List, Dict
from .base import BaseAPI

logger = logging.getLogger(__name__)


class ProjectAPI(BaseAPI):
    """API for managing projects."""

    def list_projects(self) -> List[Dict]:
        """List all projects.

        Returns:
            List of project dictionaries containing project_id and project_name
        """
        logger.info("Listing all projects")
        headers = self._get_headers()
        del headers['Content-Type']
        response = self._send_request("GET",
                                      "/dataserver/api/projects",
                                      headers=headers)
        return [{
            "project_id": p["project_id"],
            "project_name": p["project_name"]
        } for p in response.get("data", [])]

    def create_project(self, project_name: str,
                       project_description: str) -> str:
        """Create a new project.

        Args:
            project_name: Name of the project
            project_description: Description of the project

        Returns:
            Success message
        """
        logger.info("Creating project with name: %s", project_name)
        headers = self._get_headers()
        user_id = self._credentials.get_user_id()

        project_data = {
            "project_name": project_name,
            "project_description": project_description,
            "admin_user_id": user_id
        }

        self._send_request("POST",
                           "/dataserver/api/projects",
                           headers=headers,
                           data=project_data)
        logger.info("Project created successfully: %s", project_name)
        return "Project created successfully"

    def delete_project(self, project_id: str) -> str:
        """Delete a project.

        Args:
            project_id: ID of the project to delete

        Returns:
            Success message
        """
        logger.info("Deleting project with ID: %s", project_id)
        headers = self._get_headers()
        self._send_request("DELETE",
                           f"/dataserver/api/projects/{project_id}",
                           headers=headers)
        logger.info("Project deleted successfully: %s", project_id)
        return "Project deleted successfully"

    def update_project(self, project_id: str, project_name: str,
                       project_description: str) -> str:
        """Update a project.

        Args:
            project_id: ID of the project to update
            project_name: New project name
            project_description: New project description

        Returns:
            Success message
        """
        logger.info("Updating project ID: %s", project_id)
        headers = self._get_headers()
        update_info = {
            "project_name": project_name,
            "project_description": project_description
        }

        self._send_request("PUT",
                           f"/dataserver/api/projects/{project_id}",
                           headers=headers,
                           data=update_info)
        logger.info("Project updated successfully: %s", project_id)
        return "Project updated successfully"
